#include <iostream>
#include<math.h>
#include<cmath>
#include<graphics.h>
void midpointCDA(int xc,int yc,int r){
	int x=0;
	int y=r;

	
	int p=1-r;
	
	do{
		
		//plot
	putpixel(0+xc,0+yc,WHITE);
	putpixel(xc+x,yc+y,WHITE);
	putpixel(xc+y,yc+x,WHITE); // corrected
	putpixel(xc-x,yc-y,WHITE);
	putpixel(xc+x,yc-x,WHITE); // corrected
	putpixel(xc+y,yc-y,WHITE);
	putpixel(xc-x,yc+y,WHITE);
	putpixel(xc-y,yc+x,WHITE);
	putpixel(xc-y,yc-x,WHITE);
		if(p<0){
			x+=1;
			y=y;
			p=p+(2*x)+1;
		putpixel(x+xc,y+yc,WHITE);
	
			std::cout<<"\n x : "<<x<<", y : "<<y;
			std::cout<<"\n P : "<<p;
		}
		else{
			x=x+1;
			y=y-1;
			p=p+2*x-2*y+1;
			putpixel(x+xc,y+yc,WHITE);
			delay(100);
			
			std::cout<<"\n x : "<<x<<"  y : "<<y;
			std::cout<<"\n P : "<<p;
		}
	
	}
		while(x >= y); // corrected
}
int main(){
	int gd=DETECT,gm;  
    initgraph(&gd,&gm,"C:\CG Sudhashnu_Shekhar");
	int r,xc,yc;
	std::cout<<"\n Enter radius : ";
	std::cin>>r;
	std::cout<<"\n Enter xc , yc : ";
	std::cin>>xc>>yc;
	midpointCDA(xc,yc,r);
	
	
	return 0;
}
