    #include<graphics.h>
    using namespace std;
    int main(){
   	int gd=DETECT,gm;  
    initgraph(&gd,&gm,"C:\CG Sudhashnu_Shekhar");
    putpixel(3,4,WHITE);
    delay(1000);
    return 0;
	}
